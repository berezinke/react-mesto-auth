import logo  from '../images/header-logo.svg';
import React from 'react';
import { Link } from 'react-router-dom';

function Header() {
  return (
    <header className="header">
      <img src={logo} alt="Лого Место" className="logo"/>
      <Link to="/sign-in" className="register__login-link">Войти</Link>
    </header>
  );
}

export default Header;