import React from 'react';
import { Link, withRouter } from 'react-router-dom';
import PopupWithForm from '../components/PopupWithForm.js';

// import './styles/Login.css';

function Login(props) {
  const [userEmail, setUserEmail] = React.useState('');
  const [userPassword, setUserPassword] = React.useState('');

  function handleChangeUserEmail(e) {
    setUserEmail(e.target.value);    
  }
  function handleChangeUserPassword(e) {
    setUserPassword(e.target.value);    
  }

  function closePopLogin () {
    props.onClose()
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (!userEmail || !userPassword){
      return;
    }
    props.exApi.userAuthorize(userEmail, userPassword)
    .then((data) => {
      console.log(data);
      if (data.token) {
        setUserEmail('');
        setUserPassword('');
        props.handleLogin(true);
        console.log('history');
        props.history.push('/')
        props.setLoginPopupOpen(false);
      }      
    })
    .catch(err => console.log(err))
  }
  // props.setLoginPopupOpen(true);
  console.log('Login');
  return (
    <div className="login">
        <PopupWithForm 
          title = "Вход"
          name = "login"
          submit = "Войти"
          isOpen = {props.isOpen}
          onClose = {closePopLogin}
          onSubmit = {handleSubmit}
          isThinking = {props.isThinking}>
          <input type="email" 
            className="profile-change__input" 
            name="username" id="namePicNew" 
            placeholder="Email" 
            value = {userEmail}
            onChange={handleChangeUserEmail}
            required/>
          <span className="profile-change__error" id="namePicNew-error">Ок</span>
          <input type="password" 
            className="profile-change__input"
            name="password"
            id="placePicNew" 
            value = {userPassword}
            onChange={handleChangeUserPassword}
            placeholder="Пароль" required/>
          <span className="profile-change__error" id="placePicNew-error">Ок</span>
          </PopupWithForm>

          <div className="login__signup">
            <p>Ещё не зарегистрированы?</p>
            <Link to="/sign-up" className="signup__link">Зарегистрироваться</Link>
          </div>
    </div>
  )
}

export default withRouter(Login);
/*
<p className="login__welcome">
          Пожалуйста, войдите или зарегистрируйтесь, чтобы получить доступ.
        </p>
        <form onSubmit={handleSubmit} className="login__form">
          <label htmlFor="username">
            Логин:
          </label>
          <input id="username" required name="username" 
                 type="email" value={userEmail} onChange={handleChangeUserEmail} />
          <label htmlFor="password">
            Пароль:
          </label>
          <input id="password" required name="password" 
                 type="password" value={userPassword} onChange={handleChangeUserPassword} />
            <div className="login__button-container">
              <button type="submit" className="login__link">Войти</button>
            </div>
        </form>
*/