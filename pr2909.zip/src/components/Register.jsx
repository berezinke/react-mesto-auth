import React from 'react';
import { Link, withRouter } from 'react-router-dom';

// import './styles/Register.css';

function Register(props) {
  const [userEmail, setUserEmail] = React.useState('');
  const [userPassword, setUserPassword] = React.useState('');

  function handleChangeUserEmail(e) {
    setUserEmail(e.target.value);    
  }
  function handleChangeUserPassword(e) {
    setUserPassword(e.target.value);    
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (!userEmail || !userPassword){
      return;
    }
    props.exApi.userRegister(userEmail, userPassword)
    .then((res) => {
      if (res.statusCode !== 400) {
        props.history.push('/sign-in');
      }
      setUserEmail('');
      setUserPassword('');
      props.handleLogin(true);
      props.history.push('/')
    })
    .catch(err => console.log(err))
  }

  return (
      <div className="register">
        <p className="register__welcome">
            Пожалуйста, зарегистрируйтесь.
        </p>
        <form onSubmit={handleSubmit} className="register__form">
          <label htmlFor="email">
            Email:
          </label>
          <input id="email" name="email" 
                 type="email" value={userEmail} onChange={handleChangeUserEmail} />
          <label htmlFor="password">
            Пароль:
          </label>
          <input id="password" name="password" 
                 type="password" value={userPassword} onChange={handleChangeUserPassword} />
          <div className="register__button-container">
            <button type="submit" onSubmit={handleSubmit} className="register__link">Зарегистрироваться</button>
          </div>
        </form>

        <div className="register__signin">
          <p>Уже зарегистрированы?</p>
          <Link to="/sign-in" className="register__login-link">Войти</Link>
        </div>
        </div>
  )
}

export default withRouter(Register);