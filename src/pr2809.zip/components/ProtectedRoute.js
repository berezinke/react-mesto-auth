import React from "react";
import { Route, Redirect, withRouter } from "react-router-dom";

// const ProtectedRoute = ({ component: Component, ...props }) => {
const ProtectedRoute = (props) => {
  const [isMainOpen, setMainOpen] = React.useState(false)
  console.log('Prot')
  console.log(props.component);
  console.log(props.loggedIn);
  if (props.loggedIn) {
    setMainOpen(true);
  }
  React.useEffect(() => {
    if (isMainOpen) {console.log('1')}});

  return (
    <Route>
      {() =>
        props.loggedIn ? <props.component {...props} /> : <Redirect to="./sign-in" />
      }
    </Route>
  );
};

export default withRouter(ProtectedRoute);

// props.loggedIn ? <props.omponent {...props} /> : <Redirect to="./sign-in" />